"""Create editable diagrams.net pages for the architecture and schema models."""
from xml.etree.ElementTree import Element, SubElement, ElementTree
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]/"docs"/"diagrams"
ROOT.mkdir(parents=True,exist_ok=True)

def page(name, nodes, edges):
    diagram=Element("diagram",{"id":name.lower().replace(" ","-"),"name":name})
    model=SubElement(diagram,"mxGraphModel",{"dx":"1200","dy":"800","grid":"1","gridSize":"10","guides":"1","tooltips":"1","connect":"1","arrows":"1","fold":"1","page":"1","pageScale":"1","pageWidth":"1600","pageHeight":"1000","math":"0","shadow":"0"})
    root=SubElement(model,"root"); SubElement(root,"mxCell",{"id":"0"}); SubElement(root,"mxCell",{"id":"1","parent":"0"})
    for i,(label,x,y,w,h,style) in enumerate(nodes,2):
        cell=SubElement(root,"mxCell",{"id":str(i),"value":label,"style":style,"vertex":"1","parent":"1"})
        SubElement(cell,"mxGeometry",{"x":str(x),"y":str(y),"width":str(w),"height":str(h),"as":"geometry"})
    base=2+len(nodes)
    for j,(source,target,label) in enumerate(edges,base):
        cell=SubElement(root,"mxCell",{"id":str(j),"value":label,"style":"edgeStyle=orthogonalEdgeStyle;rounded=1;orthogonalLoop=1;jettySize=auto;html=1;endArrow=block;endFill=1;strokeColor=#637f9b;","edge":"1","parent":"1","source":str(2+source),"target":str(2+target)})
        SubElement(cell,"mxGeometry",{"relative":"1","as":"geometry"})
    return diagram

blue="rounded=1;whiteSpace=wrap;html=1;fillColor=#eaf2f8;strokeColor=#52718e;fontSize=14;align=left;verticalAlign=middle;spacing=10;"
table="rounded=1;whiteSpace=wrap;html=1;fillColor=#17212b;fontColor=#ffffff;strokeColor=#99aabb;fontSize=13;align=left;verticalAlign=top;spacing=10;"
pages=[]
pages.append(page("Application Flow",[
 ("HR Team / Executives",40,70,160,65,blue),("Streamlit UI<br>Employees, Projects, Reviews, Dashboard",250,65,250,85,blue),("Python Application<br>Entities, Services, Business Rules",570,65,260,85,blue),("MySQL OLTP<br>Employees, Departments, Assignments, Reviews",910,65,280,90,blue),
 ("IBM HR CSV<br>1,470 source rows",40,270,170,70,blue),("Pandas + Faker Synthesizer<br>100,000+ identities",270,265,230,80,blue),("Staging + ETL Batch Log<br>Snapshots and effective dates",570,265,260,80,blue),("OLAP Star Warehouse<br>Employee SCD2, dimensions, review facts",910,260,280,90,blue),
 ("Plotly Analytics<br>Trends, ranking, attrition, workload",690,470,280,80,blue),("Local browser<br>http://localhost:8501",1030,470,280,80,blue)],[(0,1,"forms"),(1,2,"validated actions"),(2,3,"SQL / transaction"),(4,5,"sample & synthesize"),(5,6,"batch load"),(6,7,"procedure"),(7,8,"analytical queries"),(8,9,"localhost UI")]))
pages.append(page("OLTP",[
 ("DEPARTMENTS<br><br>PK department_id<br>UQ name, code<br>active, created_at",80,60,260,150,table),
 ("EMPLOYEES<br><br>PK employee_id<br>FK department_id<br>UQ employee_number<br>name, hire date, role, level, salary, HR attrs",410,60,330,200,table),
 ("ASSIGNMENTS<br><br>PK assignment_id<br>FK employee_id, project_id<br>date range, billable, allocation 0-100",210,370,290,165,table),
 ("PROJECTS<br><br>PK project_id<br>UQ project_code<br>status: Planned / Active / Completed / Cancelled<br>start, planned end, actual end",50,650,320,175,table),
 ("REVIEWS<br><br>PK review_id<br>FK employee_id, optional project/reviewer<br>date, rating 1-5, score 0-100, status, comments",630,370,340,180,table)],[(0,1,"1 to N"),(1,2,"1 to N"),(1,4,"1 to N"),(2,3,"N to 1")]))
pages.append(page("Staging",[
 ("ETL_BATCH_LOG<br><br>PK batch_id<br>source, start/completion, status<br>read/loaded/rejected counts, error",470,50,350,160,table),
 ("STG_HR_EMPLOYEE<br><br>PK staging_row_id<br>FK batch_id<br>source_employee_number<br>synthetic_employee_number<br>all 35 original IBM columns<br>synthetic name/hire metadata",80,330,440,250,table),
 ("STG_EMPLOYEE_HISTORY<br><br>PK history_row_id<br>FK batch_id<br>source + synthetic identity mapping<br>department, role, level, income<br>effective start/end, is_current, reason",780,330,430,230,table),
 ("Generated event landing tables<br><br>STG_SYNTHETIC_ASSIGNMENT<br>STG_SYNTHETIC_REVIEW<br>marked synthetic; stable idempotency key",470,680,400,180,table)],[(0,1,"1 to N"),(0,2,"1 to N"),(0,3,"1 to N")]))
pages.append(page("OLAP Star Schema",[
 ("DIM_EMPLOYEE<br><br>PK employee_key<br>OLTP employee_id<br>SCD2 start_date / end_date / is_current<br>role, department, salary, HR attrs",480,45,380,230,table),
 ("DIM_PROJECT<br><br>PK project_key<br>UQ project_id<br>code, name, status, dates",70,380,300,160,table),
 ("FACT_PERFORMANCE_REVIEWS<br><br>PK performance_review_fact_key<br>UQ review_id<br>FK employee_key, project_key (nullable)<br>review_date_key, department_key<br>rating, score, review_count",480,370,400,200,table),
 ("DIM_DATE<br><br>PK date_key<br>UQ full_date<br>day, month, month_name, quarter, year, weekday",970,380,300,170,table),
 ("DIM_DEPARTMENT<br><br>PK department_key<br>UQ department_id<br>department_code, name, active",500,700,360,150,table)],[(0,2,"1 to N"),(1,2,"1 to N"),(3,2,"1 to N"),(4,2,"1 to N")]))

mxfile=Element("mxfile",{"host":"app.diagrams.net","modified":"2026-10-27T00:00:00.000Z","agent":"Rising Stars project","version":"24.7.17","type":"device"})
for p in pages: mxfile.append(p)
ElementTree(mxfile).write(ROOT/"rising-stars-models.drawio",encoding="utf-8",xml_declaration=True)
