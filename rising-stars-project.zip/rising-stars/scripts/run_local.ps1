$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$PythonPath = Join-Path $env:LOCALAPPDATA 'RisingStars\venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $PythonPath)) { throw 'Environment missing. Run powershell -ExecutionPolicy Bypass -File .\scripts\install_dependencies.ps1 first.' }
Set-Location -LiteralPath $ProjectRoot
& $PythonPath -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501