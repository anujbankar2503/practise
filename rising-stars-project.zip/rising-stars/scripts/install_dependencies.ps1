$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location -LiteralPath $ProjectRoot
# Keep the environment outside OneDrive, which can lock synced executables and wheel temp files.
$VenvPath = Join-Path $env:LOCALAPPDATA 'RisingStars\venv'
$PythonPath = Join-Path $VenvPath 'Scripts\python.exe'
Write-Host "Project: $ProjectRoot"
Write-Host "Local Python environment: $VenvPath"
Write-Host 'Installing bounded dependencies from this requirements.txt:'
Get-Content (Join-Path $ProjectRoot 'requirements.txt')
py -3.12 -m venv $VenvPath
if ($LASTEXITCODE -ne 0) { throw 'Could not create the environment. Verify that py -3.12 --version works.' }
$PipTemp = Join-Path $env:LOCALAPPDATA 'Temp\rising-stars-pip'
New-Item -ItemType Directory -Force -Path $PipTemp | Out-Null
$oldTemp, $oldTmp = $env:TEMP, $env:TMP
$env:TEMP = $PipTemp
$env:TMP = $PipTemp
try {
    & $PythonPath -m pip install --no-cache-dir --timeout 1800 --retries 20 -r (Join-Path $ProjectRoot 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed. Keep this window open during the long download, then check the exact pip error.' }
    & $PythonPath -m pip check
    if ($LASTEXITCODE -ne 0) { throw 'pip check found an inconsistent environment.' }
} finally {
    $env:TEMP, $env:TMP = $oldTemp, $oldTmp
}
Write-Host 'Dependencies installed and checked. Use scripts\run_local.ps1 to start the app.'