from datetime import date

import plotly.express as px
import streamlit as st

from src.controller.app_controller import AppController
from src.entities import Employee
from src.repository.base import Repository
from src.repository.employee_repository import EmployeeRepository


def _action(fn, message: str):
    try:
        result = fn()
        st.success(message)
        st.rerun()
        return result
    except Exception as exc:
        st.error(f"Could not save: {exc}")
        return None


def _dashboard(controller):
    st.title("People and performance")
    department_id = st.sidebar.number_input("Department ID filter (0 = all)", min_value=0, step=1, key="dash_dept")
    project_id = st.sidebar.number_input("Project ID filter (0 = all)", min_value=0, step=1, key="dash_project")
    try:
        result = controller.analytics.dashboard(int(department_id) or None, int(project_id) or None)
        metrics = result["metrics"]
        a,b,c,d = st.columns(4)
        a.metric("Employees reviewed", metrics.get("employees", 0) or 0)
        b.metric("Review events", metrics.get("reviews", 0) or 0)
        c.metric("Average score", metrics.get("avg_score") or "—")
        d.metric("Projects with reviews", metrics.get("projects", 0) or 0)
        st.caption("Synthetic review events are generated examples. IBM PerformanceRating is a snapshot attribute, not a dated review.")
        if result["trend"]:
            st.subheader("Year over year performance")
            st.plotly_chart(px.line(result["trend"], x="year", y="average_score", markers=True), use_container_width=True)
        else: st.info("No review history is available yet.")
        x,y = st.columns(2)
        with x:
            st.subheader("Top employees by department")
            st.dataframe(result["top"], use_container_width=True, hide_index=True)
        with y:
            st.subheader("Attrition snapshot - exploratory")
            st.caption("Descriptive associations only; this is not a validated prediction model.")
            if result["attrition"]:
                st.plotly_chart(px.bar(result["attrition"], x="department", y="attrition_pct", color="overtime", barmode="group"), use_container_width=True)
        st.subheader("Project review bottlenecks")
        st.dataframe(result["bottlenecks"], use_container_width=True, hide_index=True)
        st.subheader("Project allocation overview")
        st.dataframe(result["allocation"],use_container_width=True,hide_index=True)
        st.subheader("Employees allocated over 100%")
        if result["overloaded"]: st.dataframe(result["overloaded"],use_container_width=True,hide_index=True)
        else: st.success("No active over-allocation found.")
        st.subheader("Latest ETL batch")
        st.dataframe(result["latest"], use_container_width=True, hide_index=True)
    except Exception as exc:
        st.warning(f"Warehouse is not available yet. Configure MySQL and run the SQL setup and ETL. Details: {exc}")


def _employees(controller):
    st.title("Employee management")
    repository = EmployeeRepository()
    try:
        departments = repository.departments()
        dept_labels = {d["department_name"]: d["department_id"] for d in departments}
        search = st.text_input("Search name or employee number")
        dep = st.selectbox("Department filter", ["All"] + list(dept_labels))
        rows = controller.employees.browse(search, dept_labels.get(dep))
        st.dataframe(rows, use_container_width=True, hide_index=True)
        with st.expander("Onboard employee"):
            with st.form("employee_create"):
                c1,c2=st.columns(2)
                number=c1.text_input("Employee number", max_chars=30)
                first=c1.text_input("First name")
                last=c2.text_input("Last name")
                department=c2.selectbox("Department", list(dept_labels))
                hire=c1.date_input("Hire date", value=date.today())
                role=c2.text_input("Job role")
                level=c1.number_input("Job level", min_value=1, max_value=255, value=1)
                income=c2.number_input("Monthly income", min_value=0.0, value=0.0)
                age=c1.number_input("Age", min_value=18, max_value=100, value=30)
                gender=c2.text_input("Gender (optional)")
                if st.form_submit_button("Create employee"):
                    if not number.strip() or not first.strip() or not last.strip() or not role.strip(): st.error("Employee number, name, and role are required.")
                    else: _action(lambda: controller.employees.onboard(Employee(number,first,last,dept_labels[department],hire,role,income,int(level),gender or None,int(age))), "Employee created.")
        with st.expander("Update tracked employee attributes"):
            if rows:
                employees_by_label = {f"{r['employee_number']} - {r['first_name']} {r['last_name']} (ID {r['employee_id']})":r for r in rows}
                label=st.selectbox("Employee", list(employees_by_label))
                current=employees_by_label[label]
                with st.form("employee_tracked_update"):
                    department=st.selectbox("Department", list(dept_labels), index=max(0, next((i for i,d in enumerate(dept_labels) if dept_labels[d]==current['department_id']),0)))
                    role=st.text_input("Job role", value=current["job_role"])
                    level=st.number_input("Job level", min_value=1,max_value=255,value=int(current["job_level"] or 1))
                    salary=st.number_input("Monthly income", min_value=0.0,value=float(current["monthly_income"]))
                    if st.form_submit_button("Save tracked change"):
                        _action(lambda: controller.employees.update_tracked(current["employee_id"],dept_labels[department],role,int(level),salary), "Employee updated. Run the warehouse procedure to record the SCD Type 2 version.")
            else: st.info("Add or load employees before editing.")
    except Exception as exc: st.warning(f"Operational database is not available: {exc}")


def _departments():
    st.title("Department management")
    repo=Repository()
    try:
        departments=repo.query("SELECT * FROM DEPARTMENTS ORDER BY department_name")
        st.dataframe(departments,use_container_width=True,hide_index=True)
        with st.form("department_create"):
            name=st.text_input("Department name"); code=st.text_input("Department code",max_chars=20)
            if st.form_submit_button("Create department"):
                if not name.strip() or not code.strip(): st.error("Name and code are required.")
                else: _action(lambda: repo.execute("INSERT INTO DEPARTMENTS(department_name,department_code) VALUES(%s,%s)",(name.strip(),code.strip())),"Department created.")
        if departments:
            with st.expander("Update department"):
                choices={f"{d['department_name']} ({d['department_code']})":d for d in departments}
                choice=st.selectbox("Department to update",list(choices))
                row=choices[choice]
                with st.form("department_update"):
                    new_name=st.text_input("Name",value=row["department_name"])
                    new_code=st.text_input("Code",value=row["department_code"])
                    active=st.checkbox("Active",value=bool(row["is_active"]))
                    if st.form_submit_button("Save department"):
                        _action(lambda:repo.execute("UPDATE DEPARTMENTS SET department_name=%s,department_code=%s,is_active=%s WHERE department_id=%s",(new_name.strip(),new_code.strip(),active,row["department_id"])),"Department updated.")
    except Exception as exc: st.warning(f"Operational database is not available: {exc}")


def _projects(controller):
    st.title("Project management")
    try:
        st.dataframe(controller.projects.list(),use_container_width=True,hide_index=True)
        with st.form("project_create"):
            code=st.text_input("Project code"); name=st.text_input("Project name")
            status=st.selectbox("Status",["Planned","Active","Completed","Cancelled"])
            start=st.date_input("Start date",value=date.today()); planned=st.date_input("Planned end",value=date.today())
            if st.form_submit_button("Create project"):
                if not code.strip() or not name.strip(): st.error("Project code and name are required.")
                else: _action(lambda: controller.projects.create({"project_code":code,"project_name":name,"project_status":status,"project_start_date":start,"planned_end_date":planned}),"Project created.")
        projects=controller.projects.list()
        if projects:
            with st.expander("Update project"):
                by_name={f"{p['project_code']} - {p['project_name']}":p for p in projects}
                label=st.selectbox("Project to update",list(by_name))
                selected=by_name[label]
                with st.form("project_update"):
                    status=st.selectbox("Status",["Planned","Active","Completed","Cancelled"],index=["Planned","Active","Completed","Cancelled"].index(selected["project_status"]))
                    planned=st.date_input("Planned end",value=selected["planned_end_date"] or selected["project_start_date"])
                    if st.form_submit_button("Save project"):
                        validate=lambda: controller.projects.repository.execute("UPDATE PROJECTS SET project_status=%s,planned_end_date=%s WHERE project_id=%s",(status,planned,selected["project_id"]))
                        _action(validate,"Project updated.")
    except Exception as exc: st.warning(f"Operational database is not available: {exc}")


def _assignments(controller):
    st.title("Project assignments")
    try:
        st.dataframe(controller.assignments.list(),use_container_width=True,hide_index=True)
        employees=controller.employees.browse(limit=2000); projects=controller.projects.list()
        with st.form("assignment_create"):
            emp=st.selectbox("Employee",employees,format_func=lambda e:f"{e['employee_number']} - {e['first_name']} {e['last_name']}")
            proj=st.selectbox("Project",projects,format_func=lambda p:f"{p['project_code']} - {p['project_name']}")
            start=st.date_input("Assignment start",value=date.today()); end=st.date_input("Assignment end (use start if ongoing)",value=date.today())
            alloc=st.number_input("Allocation percent",min_value=0,max_value=100,value=100); billable=st.checkbox("Billable")
            if st.form_submit_button("Assign"):
                _action(lambda: controller.assignments.create({"employee_id":emp["employee_id"],"project_id":proj["project_id"],"start_date":start,"end_date":None if end==start else end,"allocation_percentage":alloc,"billable_flag":billable}),"Assignment created.")
    except Exception as exc: st.warning(f"Operational database is not available or no employees/projects exist: {exc}")


def _reviews(controller):
    st.title("Performance reviews")
    try:
        employees=controller.employees.browse(limit=2000); projects=controller.projects.list()
        st.dataframe(controller.reviews.list(),use_container_width=True,hide_index=True)
        with st.form("review_create"):
            emp=st.selectbox("Employee",employees,format_func=lambda e:f"{e['employee_number']} - {e['first_name']} {e['last_name']}")
            project=st.selectbox("Project (optional)",[None]+projects,format_func=lambda p:"No project" if p is None else p["project_name"])
            reviewer=st.selectbox("Reviewer (optional)",[None]+employees,format_func=lambda e:"No reviewer" if e is None else f"{e['first_name']} {e['last_name']} ({e['employee_number']})")
            review_date=st.date_input("Review date",value=date.today())
            rating=st.selectbox("Rating",[None,1,2,3,4,5],format_func=lambda x:"Pending" if x is None else str(x))
            score=st.number_input("Score (0-100)",min_value=0.0,max_value=100.0,value=0.0)
            comments=st.text_area("Comments")
            if st.form_submit_button("Save review"):
                _action(lambda:controller.reviews.create({"employee_id":emp["employee_id"],"reviewer_employee_id":reviewer["employee_id"] if reviewer else None,"project_id":project["project_id"] if project else None,"review_date":review_date,"performance_rating":rating,"performance_score":score if rating is not None else None,"comments":comments or None}),"Review saved.")
        st.caption("The IBM PerformanceRating value is an undated snapshot attribute and is not loaded as a review event.")
    except Exception as exc: st.warning(f"Operational database is not available or no employees exist: {exc}")


def main():
    st.set_page_config(page_title="Rising Stars | People Analytics",page_icon="⭐",layout="wide")
    st.sidebar.title("Rising Stars")
    page=st.sidebar.radio("Navigate",["Dashboard","Employees","Departments","Projects","Assignments","Reviews","Analytics"])
    controller=AppController()
    if page in ("Dashboard","Analytics"): _dashboard(controller)
    elif page=="Employees": _employees(controller)
    elif page=="Departments": _departments()
    elif page=="Projects": _projects(controller)
    elif page=="Assignments": _assignments(controller)
    else: _reviews(controller)

