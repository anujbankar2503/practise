USE rising_stars_oltp;
CREATE TABLE IF NOT EXISTS DEPARTMENTS (
 department_id INT AUTO_INCREMENT PRIMARY KEY, department_name VARCHAR(200) NOT NULL UNIQUE,
 department_code VARCHAR(20) NOT NULL UNIQUE, is_active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS EMPLOYEES (
 employee_id BIGINT AUTO_INCREMENT PRIMARY KEY, department_id INT NOT NULL,
 employee_number VARCHAR(30) NOT NULL UNIQUE, first_name VARCHAR(60) NOT NULL, last_name VARCHAR(60) NOT NULL,
 hire_date DATE NOT NULL, job_role VARCHAR(50) NOT NULL, job_level TINYINT UNSIGNED NULL,
 gender VARCHAR(30) NULL, work_location VARCHAR(100) NOT NULL DEFAULT 'Unspecified',
 monthly_income DECIMAL(12,2) NOT NULL CHECK(monthly_income >= 0), created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP, address VARCHAR(250) NULL, city VARCHAR(100) NULL,
 state VARCHAR(100) NULL, age TINYINT UNSIGNED NULL CHECK(age BETWEEN 18 AND 100), marital_status VARCHAR(20) NULL,
 education TINYINT UNSIGNED NULL CHECK(education BETWEEN 1 AND 5), education_field VARCHAR(50) NULL,
 business_travel VARCHAR(30) NULL, distance_from_home TINYINT UNSIGNED NULL,
 overtime ENUM('Yes','No') NULL, attrition_status ENUM('Yes','No') NULL,
 total_working_years SMALLINT UNSIGNED NULL, num_companies_worked SMALLINT UNSIGNED NULL,
 CONSTRAINT fk_employee_department FOREIGN KEY(department_id) REFERENCES DEPARTMENTS(department_id)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS PROJECTS (
 project_id BIGINT AUTO_INCREMENT PRIMARY KEY, project_code VARCHAR(30) NOT NULL UNIQUE,
 project_name VARCHAR(150) NOT NULL, project_status ENUM('Planned','Active','Completed','Cancelled') NOT NULL DEFAULT 'Planned',
 project_start_date DATE NOT NULL, planned_end_date DATE NULL, actual_end_date DATE NULL,
 CHECK(planned_end_date IS NULL OR planned_end_date >= project_start_date),
 CHECK(actual_end_date IS NULL OR actual_end_date >= project_start_date)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS ASSIGNMENTS (
 assignment_id BIGINT AUTO_INCREMENT PRIMARY KEY, employee_id BIGINT NOT NULL, project_id BIGINT NOT NULL,
 start_date DATE NOT NULL, end_date DATE NULL, billable_flag BOOLEAN NOT NULL DEFAULT FALSE,
 allocation_percentage DECIMAL(5,2) NOT NULL CHECK(allocation_percentage BETWEEN 0 AND 100),
 synthetic_assignment_key VARCHAR(40) NULL UNIQUE,
 CHECK(end_date IS NULL OR end_date >= start_date),
 CONSTRAINT fk_assignment_employee FOREIGN KEY(employee_id) REFERENCES EMPLOYEES(employee_id),
 CONSTRAINT fk_assignment_project FOREIGN KEY(project_id) REFERENCES PROJECTS(project_id),
 INDEX ix_assignment_project_dates(project_id,start_date,end_date), INDEX ix_assignment_employee(employee_id,start_date)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS REVIEWS (
 review_id BIGINT AUTO_INCREMENT PRIMARY KEY, reviewer_employee_id BIGINT NULL, employee_id BIGINT NOT NULL,
 project_id BIGINT NULL, review_date DATE NOT NULL, performance_rating TINYINT UNSIGNED NULL,
 performance_score DECIMAL(5,2) NULL, review_status VARCHAR(20) NOT NULL DEFAULT 'Pending', comments TEXT NULL,
 synthetic_event_key VARCHAR(40) NULL UNIQUE,
 CHECK(performance_rating IS NULL OR performance_rating BETWEEN 1 AND 5),
 CHECK(performance_score IS NULL OR performance_score BETWEEN 0 AND 100),
 CONSTRAINT fk_review_employee FOREIGN KEY(employee_id) REFERENCES EMPLOYEES(employee_id),
 CONSTRAINT fk_review_reviewer FOREIGN KEY(reviewer_employee_id) REFERENCES EMPLOYEES(employee_id),
 CONSTRAINT fk_review_project FOREIGN KEY(project_id) REFERENCES PROJECTS(project_id),
 INDEX ix_review_employee_date(employee_id,review_date), INDEX ix_review_project(project_id,review_date)
) ENGINE=InnoDB;
