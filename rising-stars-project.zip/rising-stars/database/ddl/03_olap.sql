USE rising_stars_olap;
CREATE TABLE IF NOT EXISTS DIM_DEPARTMENT (
 department_key INT AUTO_INCREMENT PRIMARY KEY, department_id INT NOT NULL UNIQUE,
 department_code VARCHAR(20) NOT NULL, department_name VARCHAR(200) NOT NULL, is_active BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS DIM_EMPLOYEE (
 employee_key BIGINT AUTO_INCREMENT PRIMARY KEY, employee_id BIGINT NOT NULL,
 employee_number VARCHAR(30) NOT NULL, department_id INT NOT NULL,
 first_name VARCHAR(60) NOT NULL, last_name VARCHAR(60) NOT NULL, age TINYINT UNSIGNED NULL,
 job_role VARCHAR(50) NOT NULL, job_level TINYINT UNSIGNED NULL, gender VARCHAR(30) NULL,
 monthly_income DECIMAL(12,2) NOT NULL, start_date DATETIME NOT NULL,
 end_date DATETIME NULL, is_current BOOLEAN NOT NULL DEFAULT TRUE,
 marital_status VARCHAR(20) NULL, education TINYINT UNSIGNED NULL,
 education_field VARCHAR(50) NULL, business_travel VARCHAR(30) NULL,
 distance_from_home TINYINT UNSIGNED NULL, overtime ENUM('Yes','No') NULL,
 attrition_status ENUM('Yes','No') NULL, total_working_years SMALLINT UNSIGNED NULL,
 num_companies_worked SMALLINT UNSIGNED NULL,
 current_employee_id BIGINT GENERATED ALWAYS AS (CASE WHEN is_current THEN employee_id ELSE NULL END) STORED,
 UNIQUE KEY uq_dim_employee_current(current_employee_id),
 UNIQUE KEY uq_dim_employee_version(employee_id,start_date),
 INDEX ix_dim_employee_business(employee_id,start_date,end_date), INDEX ix_dim_employee_number(employee_number)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS DIM_PROJECT (
 project_key BIGINT AUTO_INCREMENT PRIMARY KEY, project_id BIGINT NOT NULL UNIQUE,
 project_code VARCHAR(30) NOT NULL, project_name VARCHAR(150) NOT NULL,
 project_status ENUM('Planned','Active','Completed','Cancelled') NOT NULL DEFAULT 'Planned',
 project_start_date DATE NOT NULL, planned_end_date DATE NULL, actual_end_date DATE NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS DIM_DATE (
 date_key INT PRIMARY KEY, full_date DATE NOT NULL UNIQUE,
 day TINYINT UNSIGNED NOT NULL, month TINYINT UNSIGNED NOT NULL,
 month_name VARCHAR(15) NOT NULL, quarter TINYINT UNSIGNED NOT NULL,
 year SMALLINT UNSIGNED NOT NULL, day_of_week VARCHAR(10) NOT NULL,
 CHECK(day BETWEEN 1 AND 31), CHECK(month BETWEEN 1 AND 12), CHECK(quarter BETWEEN 1 AND 4)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS FACT_PERFORMANCE_REVIEWS (
 performance_review_fact_key BIGINT AUTO_INCREMENT PRIMARY KEY,
 review_id BIGINT NOT NULL UNIQUE, employee_key BIGINT NOT NULL,
 project_key BIGINT NULL, review_date_key INT NOT NULL, department_key INT NOT NULL,
 performance_rating TINYINT UNSIGNED NULL, performance_score DECIMAL(5,2) NULL,
 review_count TINYINT UNSIGNED NOT NULL DEFAULT 1,
 CHECK(performance_rating IS NULL OR performance_rating BETWEEN 1 AND 5),
 CHECK(performance_score IS NULL OR performance_score BETWEEN 0 AND 100),
 FOREIGN KEY(employee_key) REFERENCES DIM_EMPLOYEE(employee_key),
 FOREIGN KEY(project_key) REFERENCES DIM_PROJECT(project_key),
 FOREIGN KEY(review_date_key) REFERENCES DIM_DATE(date_key),
 FOREIGN KEY(department_key) REFERENCES DIM_DEPARTMENT(department_key),
 INDEX ix_fact_date_department(review_date_key,department_key), INDEX ix_fact_project(project_key)
) ENGINE=InnoDB;
