USE rising_stars_staging;
CREATE TABLE IF NOT EXISTS ETL_BATCH_LOG (
 batch_id BIGINT AUTO_INCREMENT PRIMARY KEY, source_name VARCHAR(100) NOT NULL,
 load_started_at DATETIME NOT NULL, load_completed_at DATETIME NULL,
 load_status VARCHAR(20) NOT NULL, rows_read INT NOT NULL DEFAULT 0,
 rows_loaded INT NOT NULL DEFAULT 0, rows_rejected INT NOT NULL DEFAULT 0, error_message TEXT NULL,
 INDEX ix_batch_status_start(load_status,load_started_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS STG_HR_EMPLOYEE (
 staging_row_id BIGINT AUTO_INCREMENT PRIMARY KEY, batch_id BIGINT NOT NULL,
 source_employee_number INT NOT NULL, synthetic_employee_number VARCHAR(30) NULL,
 synthetic_first_name VARCHAR(60) NULL, synthetic_last_name VARCHAR(60) NULL, synthetic_hire_date DATE NULL,
 Age TINYINT UNSIGNED NOT NULL, Attrition ENUM('Yes','No') NOT NULL,
 BusinessTravel VARCHAR(30) NOT NULL, DailyRate INT UNSIGNED NOT NULL,
 Department VARCHAR(100) NOT NULL, DistanceFromHome TINYINT UNSIGNED NOT NULL,
 Education TINYINT UNSIGNED NOT NULL, EducationField VARCHAR(50) NOT NULL,
 EmployeeCount TINYINT UNSIGNED NOT NULL, EmployeeNumber INT NOT NULL,
 EnvironmentSatisfaction TINYINT UNSIGNED NOT NULL, Gender VARCHAR(20) NOT NULL,
 HourlyRate TINYINT UNSIGNED NOT NULL, JobInvolvement TINYINT UNSIGNED NOT NULL,
 JobLevel TINYINT UNSIGNED NOT NULL, JobRole VARCHAR(50) NOT NULL,
 JobSatisfaction TINYINT UNSIGNED NOT NULL, MaritalStatus VARCHAR(20) NOT NULL,
 MonthlyIncome INT UNSIGNED NOT NULL, MonthlyRate INT UNSIGNED NOT NULL,
 NumCompaniesWorked TINYINT UNSIGNED NOT NULL, Over18 CHAR(1) NOT NULL,
 OverTime ENUM('Yes','No') NOT NULL, PercentSalaryHike TINYINT UNSIGNED NOT NULL,
 PerformanceRating TINYINT UNSIGNED NOT NULL, RelationshipSatisfaction TINYINT UNSIGNED NOT NULL,
 StandardHours SMALLINT UNSIGNED NOT NULL, StockOptionLevel TINYINT UNSIGNED NOT NULL,
 TotalWorkingYears SMALLINT UNSIGNED NOT NULL, TrainingTimesLastYear TINYINT UNSIGNED NOT NULL,
 WorkLifeBalance TINYINT UNSIGNED NOT NULL, YearsAtCompany TINYINT UNSIGNED NOT NULL,
 YearsInCurrentRole TINYINT UNSIGNED NOT NULL, YearsSinceLastPromotion TINYINT UNSIGNED NOT NULL,
 YearsWithCurrManager TINYINT UNSIGNED NOT NULL, loaded_at DATETIME NOT NULL,
 FOREIGN KEY(batch_id) REFERENCES ETL_BATCH_LOG(batch_id),
 INDEX ix_stg_batch_identity(batch_id,synthetic_employee_number), INDEX ix_stg_source_employee(source_employee_number)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS STG_EMPLOYEE_HISTORY (
 history_row_id BIGINT AUTO_INCREMENT PRIMARY KEY, batch_id BIGINT NOT NULL,
 source_employee_number INT NOT NULL, synthetic_employee_number VARCHAR(30) NULL,
 department VARCHAR(100) NOT NULL, job_role VARCHAR(50) NOT NULL,
 job_level TINYINT UNSIGNED NULL, monthly_income DECIMAL(12,2) NULL,
 effective_start_date DATETIME NOT NULL, effective_end_date DATETIME NULL,
 is_current BOOLEAN NOT NULL, change_reason VARCHAR(100) NULL, loaded_at DATETIME NOT NULL,
 FOREIGN KEY(batch_id) REFERENCES ETL_BATCH_LOG(batch_id),
 INDEX ix_history_lookup(synthetic_employee_number,effective_start_date,effective_end_date)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS STG_SYNTHETIC_REVIEW (
 synthetic_review_row_id BIGINT AUTO_INCREMENT PRIMARY KEY,batch_id BIGINT NOT NULL,
 synthetic_event_key VARCHAR(40) NOT NULL,synthetic_employee_number VARCHAR(30) NOT NULL,
 project_code VARCHAR(30) NULL,review_date DATE NOT NULL,performance_rating TINYINT UNSIGNED NOT NULL,
 performance_score DECIMAL(5,2) NOT NULL,synthetic_record BOOLEAN NOT NULL DEFAULT TRUE,
 FOREIGN KEY(batch_id) REFERENCES ETL_BATCH_LOG(batch_id),UNIQUE KEY uq_stage_review(batch_id,synthetic_event_key)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS STG_SYNTHETIC_ASSIGNMENT (
 synthetic_assignment_row_id BIGINT AUTO_INCREMENT PRIMARY KEY,batch_id BIGINT NOT NULL,
 synthetic_assignment_key VARCHAR(40) NOT NULL,synthetic_employee_number VARCHAR(30) NOT NULL,
 project_code VARCHAR(30) NOT NULL,start_date DATE NOT NULL,end_date DATE NULL,
 billable_flag BOOLEAN NOT NULL,allocation_percentage DECIMAL(5,2) NOT NULL,
 synthetic_record BOOLEAN NOT NULL DEFAULT TRUE,
 FOREIGN KEY(batch_id) REFERENCES ETL_BATCH_LOG(batch_id),UNIQUE KEY uq_stage_assignment(batch_id,synthetic_assignment_key),
 CHECK(allocation_percentage BETWEEN 0 AND 100),CHECK(end_date IS NULL OR end_date>=start_date)
) ENGINE=InnoDB;
