USE rising_stars_staging;
DELIMITER $$
DROP PROCEDURE IF EXISTS sp_load_olap_from_staging$$
CREATE PROCEDURE sp_load_olap_from_staging(IN p_batch_id BIGINT)
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;
  START TRANSACTION;

  INSERT INTO rising_stars_oltp.EMPLOYEES
    (employee_number,department_id,first_name,last_name,hire_date,job_role,job_level,gender,work_location,
     monthly_income,age,marital_status,education,education_field,business_travel,distance_from_home,overtime,
     attrition_status,total_working_years,num_companies_worked)
  SELECT s.synthetic_employee_number,d.department_id,s.synthetic_first_name,s.synthetic_last_name,
    COALESCE(s.synthetic_hire_date,CURRENT_DATE),h.job_role,h.job_level,s.Gender,'Unspecified',COALESCE(h.monthly_income,s.MonthlyIncome),s.Age,
    s.MaritalStatus,s.Education,s.EducationField,s.BusinessTravel,s.DistanceFromHome,s.OverTime,s.Attrition,
    s.TotalWorkingYears,s.NumCompaniesWorked
  FROM STG_HR_EMPLOYEE s
  JOIN STG_EMPLOYEE_HISTORY h ON h.batch_id=s.batch_id AND h.synthetic_employee_number=s.synthetic_employee_number AND h.is_current=TRUE
  JOIN rising_stars_oltp.DEPARTMENTS d ON d.department_name=h.department
  WHERE s.batch_id=p_batch_id
  ON DUPLICATE KEY UPDATE employee_number=VALUES(employee_number);

  INSERT INTO rising_stars_oltp.ASSIGNMENTS
    (synthetic_assignment_key,employee_id,project_id,start_date,end_date,billable_flag,allocation_percentage)
  SELECT a.synthetic_assignment_key,e.employee_id,p.project_id,a.start_date,a.end_date,a.billable_flag,a.allocation_percentage
  FROM STG_SYNTHETIC_ASSIGNMENT a
  JOIN rising_stars_oltp.EMPLOYEES e ON e.employee_number=a.synthetic_employee_number
  JOIN rising_stars_oltp.PROJECTS p ON p.project_code=a.project_code
  WHERE a.batch_id=p_batch_id
  ON DUPLICATE KEY UPDATE synthetic_assignment_key=VALUES(synthetic_assignment_key);

  INSERT INTO rising_stars_oltp.REVIEWS
    (synthetic_event_key,employee_id,project_id,review_date,performance_rating,performance_score,review_status,comments)
  SELECT r.synthetic_event_key,e.employee_id,p.project_id,r.review_date,r.performance_rating,r.performance_score,
         'Completed','Synthetic generated review event'
  FROM STG_SYNTHETIC_REVIEW r
  JOIN rising_stars_oltp.EMPLOYEES e ON e.employee_number=r.synthetic_employee_number
  LEFT JOIN rising_stars_oltp.PROJECTS p ON p.project_code=r.project_code
  WHERE r.batch_id=p_batch_id
  ON DUPLICATE KEY UPDATE synthetic_event_key=VALUES(synthetic_event_key);

  INSERT INTO rising_stars_olap.DIM_DEPARTMENT(department_id,department_code,department_name,is_active)
  SELECT d.department_id,d.department_code,d.department_name,d.is_active
  FROM rising_stars_oltp.DEPARTMENTS d
  ON DUPLICATE KEY UPDATE department_code=VALUES(department_code),department_name=VALUES(department_name),is_active=VALUES(is_active);

  INSERT INTO rising_stars_olap.DIM_PROJECT(project_id,project_code,project_name,project_status,project_start_date,planned_end_date,actual_end_date)
  SELECT p.project_id,p.project_code,p.project_name,p.project_status,p.project_start_date,p.planned_end_date,p.actual_end_date
  FROM rising_stars_oltp.PROJECTS p
  ON DUPLICATE KEY UPDATE project_code=VALUES(project_code),project_name=VALUES(project_name),project_status=VALUES(project_status),planned_end_date=VALUES(planned_end_date),actual_end_date=VALUES(actual_end_date);

  -- Initial and changed effective-dated rows are represented directly by staging history.
  -- The unique employee/start_date key makes reruns idempotent; generated histories are synthetic by policy.
  INSERT INTO rising_stars_olap.DIM_EMPLOYEE
    (employee_id,employee_number,department_id,first_name,last_name,age,job_role,job_level,gender,monthly_income,
     start_date,end_date,is_current,marital_status,education,education_field,business_travel,distance_from_home,
     overtime,attrition_status,total_working_years,num_companies_worked)
  SELECT e.employee_id,e.employee_number,d.department_id,e.first_name,e.last_name,s.Age,h.job_role,h.job_level,
         s.Gender,COALESCE(h.monthly_income,s.MonthlyIncome),h.effective_start_date,h.effective_end_date,
         h.is_current,s.MaritalStatus,s.Education,s.EducationField,s.BusinessTravel,s.DistanceFromHome,
         s.OverTime,s.Attrition,s.TotalWorkingYears,s.NumCompaniesWorked
  FROM STG_EMPLOYEE_HISTORY h
  JOIN rising_stars_oltp.EMPLOYEES e ON e.employee_number=h.synthetic_employee_number
  JOIN STG_HR_EMPLOYEE s ON s.batch_id=h.batch_id AND s.synthetic_employee_number=h.synthetic_employee_number
  JOIN rising_stars_oltp.DEPARTMENTS d ON d.department_name=h.department
  WHERE h.batch_id=p_batch_id
  ON DUPLICATE KEY UPDATE employee_number=VALUES(employee_number);

  INSERT INTO rising_stars_olap.DIM_DATE(date_key,full_date,day,month,month_name,quarter,year,day_of_week)
  SELECT DISTINCT CAST(DATE_FORMAT(r.review_date,'%Y%m%d') AS UNSIGNED),r.review_date,
         DAY(r.review_date),MONTH(r.review_date),DATE_FORMAT(r.review_date,'%M'),QUARTER(r.review_date),
         YEAR(r.review_date),DATE_FORMAT(r.review_date,'%W')
  FROM rising_stars_oltp.REVIEWS r
  ON DUPLICATE KEY UPDATE full_date=VALUES(full_date);

  INSERT INTO rising_stars_olap.FACT_PERFORMANCE_REVIEWS
    (review_id,employee_key,project_key,review_date_key,department_key,performance_rating,performance_score,review_count)
  SELECT r.review_id,e.employee_key,p.project_key,CAST(DATE_FORMAT(r.review_date,'%Y%m%d') AS UNSIGNED),
         d.department_key,r.performance_rating,r.performance_score,1
  FROM rising_stars_oltp.REVIEWS r
  JOIN rising_stars_oltp.EMPLOYEES oe ON oe.employee_id=r.employee_id
  JOIN rising_stars_olap.DIM_EMPLOYEE e ON e.employee_id=oe.employee_id
    AND e.start_date <= r.review_date AND (e.end_date IS NULL OR r.review_date < e.end_date)
  JOIN rising_stars_olap.DIM_DEPARTMENT d ON d.department_id=e.department_id
  LEFT JOIN rising_stars_olap.DIM_PROJECT p ON p.project_id=r.project_id
  WHERE NOT EXISTS (SELECT 1 FROM rising_stars_olap.FACT_PERFORMANCE_REVIEWS f WHERE f.review_id=r.review_id)
  ON DUPLICATE KEY UPDATE review_id=VALUES(review_id);

  COMMIT;
END$$
DELIMITER ;
