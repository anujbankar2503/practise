USE rising_stars_olap;
DELIMITER $$
DROP PROCEDURE IF EXISTS sp_sync_review_fact$$
CREATE PROCEDURE sp_sync_review_fact(IN p_review_id BIGINT)
BEGIN
  INSERT INTO DIM_PROJECT(project_id,project_code,project_name,project_status,project_start_date,planned_end_date,actual_end_date)
  SELECT project_id,project_code,project_name,project_status,project_start_date,planned_end_date,actual_end_date
  FROM rising_stars_oltp.PROJECTS
  ON DUPLICATE KEY UPDATE project_code=VALUES(project_code),project_name=VALUES(project_name),project_status=VALUES(project_status),planned_end_date=VALUES(planned_end_date),actual_end_date=VALUES(actual_end_date);

  INSERT INTO DIM_DATE(date_key,full_date,day,month,month_name,quarter,year,day_of_week)
  SELECT CAST(DATE_FORMAT(review_date,'%Y%m%d') AS UNSIGNED),review_date,DAY(review_date),MONTH(review_date),
         DATE_FORMAT(review_date,'%M'),QUARTER(review_date),YEAR(review_date),DATE_FORMAT(review_date,'%W')
  FROM rising_stars_oltp.REVIEWS WHERE review_id=p_review_id
  ON DUPLICATE KEY UPDATE full_date=VALUES(full_date);

  INSERT INTO FACT_PERFORMANCE_REVIEWS
    (review_id,employee_key,project_key,review_date_key,department_key,performance_rating,performance_score,review_count)
  SELECT r.review_id,e.employee_key,p.project_key,CAST(DATE_FORMAT(r.review_date,'%Y%m%d') AS UNSIGNED),
         d.department_key,r.performance_rating,r.performance_score,1
  FROM rising_stars_oltp.REVIEWS r
  JOIN DIM_EMPLOYEE e ON e.employee_id=r.employee_id AND e.start_date<=r.review_date AND (e.end_date IS NULL OR r.review_date<e.end_date)
  JOIN DIM_DEPARTMENT d ON d.department_id=e.department_id
  LEFT JOIN DIM_PROJECT p ON p.project_id=r.project_id
  WHERE r.review_id=p_review_id
  ON DUPLICATE KEY UPDATE employee_key=VALUES(employee_key),project_key=VALUES(project_key),
    review_date_key=VALUES(review_date_key),department_key=VALUES(department_key),
    performance_rating=VALUES(performance_rating),performance_score=VALUES(performance_score);
END$$
DELIMITER ;
