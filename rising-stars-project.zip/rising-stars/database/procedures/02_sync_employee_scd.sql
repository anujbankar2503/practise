USE rising_stars_olap;
DELIMITER $$
DROP PROCEDURE IF EXISTS sp_sync_employee_scd$$
CREATE PROCEDURE sp_sync_employee_scd(IN p_employee_id BIGINT)
BEGIN
  DECLARE v_employee_key BIGINT DEFAULT NULL;
  DECLARE v_changed INT DEFAULT 0;
  DECLARE v_start_date DATETIME DEFAULT NULL;
  INSERT INTO DIM_DEPARTMENT(department_id,department_code,department_name,is_active)
  SELECT department_id,department_code,department_name,is_active FROM rising_stars_oltp.DEPARTMENTS
  ON DUPLICATE KEY UPDATE department_code=VALUES(department_code),department_name=VALUES(department_name),is_active=VALUES(is_active);
  SELECT employee_key INTO v_employee_key FROM DIM_EMPLOYEE
   WHERE employee_id=p_employee_id AND is_current=TRUE FOR UPDATE;
  IF v_employee_key IS NOT NULL THEN
    SELECT start_date INTO v_start_date FROM DIM_EMPLOYEE WHERE employee_key=v_employee_key;
    SELECT COUNT(*) INTO v_changed FROM DIM_EMPLOYEE de
    JOIN rising_stars_oltp.EMPLOYEES e ON e.employee_id=de.employee_id
    WHERE de.employee_key=v_employee_key AND
      (de.department_id<>e.department_id OR de.job_role<>e.job_role OR
       NOT (de.job_level <=> e.job_level) OR de.monthly_income<>e.monthly_income);
  ELSE
    SET v_changed=1;
  END IF;
  IF v_changed>0 THEN
    IF v_employee_key IS NOT NULL AND DATE(v_start_date)=CURRENT_DATE THEN
      UPDATE DIM_EMPLOYEE de JOIN rising_stars_oltp.EMPLOYEES e ON e.employee_id=de.employee_id
      SET de.department_id=e.department_id,de.first_name=e.first_name,de.last_name=e.last_name,de.age=e.age,
          de.job_role=e.job_role,de.job_level=e.job_level,de.gender=e.gender,de.monthly_income=e.monthly_income,
          de.marital_status=e.marital_status,de.education=e.education,de.education_field=e.education_field,
          de.business_travel=e.business_travel,de.distance_from_home=e.distance_from_home,de.overtime=e.overtime,
          de.attrition_status=e.attrition_status,de.total_working_years=e.total_working_years,
          de.num_companies_worked=e.num_companies_worked
      WHERE de.employee_key=v_employee_key;
    ELSE
      UPDATE DIM_EMPLOYEE SET is_current=FALSE,end_date=CURRENT_DATE
      WHERE employee_id=p_employee_id AND is_current=TRUE;
    INSERT INTO DIM_EMPLOYEE(employee_id,employee_number,department_id,first_name,last_name,age,job_role,job_level,
      gender,monthly_income,start_date,end_date,is_current,marital_status,education,education_field,business_travel,
      distance_from_home,overtime,attrition_status,total_working_years,num_companies_worked)
    SELECT e.employee_id,e.employee_number,e.department_id,e.first_name,e.last_name,e.age,e.job_role,e.job_level,
      e.gender,e.monthly_income,CURRENT_DATE,NULL,TRUE,e.marital_status,e.education,e.education_field,e.business_travel,
      e.distance_from_home,e.overtime,e.attrition_status,e.total_working_years,e.num_companies_worked
    FROM rising_stars_oltp.EMPLOYEES e WHERE e.employee_id=p_employee_id;
    END IF;
  END IF;
END$$
DELIMITER ;
