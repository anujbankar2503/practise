USE rising_stars_olap;
-- Year-over-year performance trend.
SELECT d.year, ROUND(AVG(f.performance_score),2) average_score, SUM(f.review_count) review_count
FROM FACT_PERFORMANCE_REVIEWS f JOIN DIM_DATE d ON d.date_key=f.review_date_key
GROUP BY d.year ORDER BY d.year;

-- Top employees within each department, using DENSE_RANK.
WITH employee_scores AS (
 SELECT de.department_key,de.department_name,e.employee_id,
        CONCAT(e.first_name,' ',e.last_name) employee_name,AVG(f.performance_score) average_score
 FROM FACT_PERFORMANCE_REVIEWS f JOIN DIM_EMPLOYEE e USING(employee_key)
 JOIN DIM_DEPARTMENT de USING(department_key)
 GROUP BY de.department_key,de.department_name,e.employee_id,e.first_name,e.last_name
), ranked AS (
 SELECT employee_scores.*, DENSE_RANK() OVER(PARTITION BY department_key ORDER BY average_score DESC) department_rank
 FROM employee_scores
)
SELECT * FROM ranked WHERE department_rank <= 10 ORDER BY department_name,department_rank;

-- Exploratory attrition proportions from current snapshot attributes, not a prediction model.
SELECT department,overtime,COUNT(*) employees,SUM(attrition_status='Yes') attrition_count,
       ROUND(100*AVG(attrition_status='Yes'),1) attrition_percent
FROM DIM_EMPLOYEE WHERE is_current=TRUE GROUP BY department,overtime ORDER BY attrition_percent DESC;

-- Project allocation and review bottleneck proxy.
SELECT p.project_name,COUNT(DISTINCT a.employee_id) assigned_employees,
       SUM(CASE WHEN a.end_date IS NULL OR a.end_date>=CURRENT_DATE THEN a.allocation_percentage ELSE 0 END) active_allocation_pct
FROM rising_stars_oltp.ASSIGNMENTS a JOIN rising_stars_oltp.PROJECTS op USING(project_id)
JOIN DIM_PROJECT p ON p.project_id=op.project_id GROUP BY p.project_id,p.project_name ORDER BY active_allocation_pct DESC;

-- Data quality checks.
SELECT employee_id,COUNT(*) current_versions FROM DIM_EMPLOYEE WHERE is_current=TRUE GROUP BY employee_id HAVING COUNT(*)<>1;
SELECT COUNT(*) orphaned_date_rows FROM FACT_PERFORMANCE_REVIEWS f LEFT JOIN DIM_DATE d ON d.date_key=f.review_date_key WHERE d.date_key IS NULL;
SELECT review_id,COUNT(*) duplicate_facts FROM FACT_PERFORMANCE_REVIEWS GROUP BY review_id HAVING COUNT(*)>1;
