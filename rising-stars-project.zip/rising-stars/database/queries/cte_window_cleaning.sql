USE rising_stars_staging;
-- Deduplicate an incoming batch deterministically; retain latest loaded staging row per synthetic identity.
WITH ranked_source AS (
 SELECT s.*,ROW_NUMBER() OVER(PARTITION BY batch_id,synthetic_employee_number ORDER BY loaded_at DESC,staging_row_id DESC) AS row_num
 FROM STG_HR_EMPLOYEE s
)
SELECT * FROM ranked_source WHERE row_num=1;

-- Detect overlapping synthetic history intervals. End date is exclusive.
WITH ordered_history AS (
 SELECT h.*,LEAD(effective_start_date) OVER(PARTITION BY synthetic_employee_number ORDER BY effective_start_date) next_start
 FROM STG_EMPLOYEE_HISTORY h
)
SELECT history_row_id,synthetic_employee_number,effective_end_date,next_start
FROM ordered_history WHERE next_start IS NOT NULL AND (effective_end_date IS NULL OR effective_end_date>next_start);
