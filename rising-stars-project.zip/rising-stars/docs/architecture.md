# Architecture

The system follows `frontend -> controller -> service -> repository -> MySQL`. Streamlit pages collect user input and render results. The controller constructs service workflows, services enforce business rules, and repositories use parameterized SQL. The `DatabaseConnection` Singleton creates short-lived connections and transaction scopes.

Three separate MySQL schemas are used: `rising_stars_oltp` for operational entities, `rising_stars_staging` for audited source batches and effective-dated staging history, and `rising_stars_olap` for the dimensional model. The warehouse uses surrogate dimension keys; review facts join to the employee version valid on the review date using `start_date <= review_date AND (end_date IS NULL OR review_date < end_date)`.

The supplied diagrams' tables are retained. The implementation adds only a few integration fields: synthetic names/hire date in staging because the IBM file has none, a unique generated event key to make synthetic review ingestion repeatable, and a generated current employee identifier to enforce one current SCD row in MySQL. Project statuses remain the agreed four values.
