# Requirements traceability

| Requirement | Implementation |
|---|---|
| Three MySQL schemas and diagram entities | `database/ddl/00_create_schemas.sql`; `01_oltp.sql`; `02_staging.sql`; `03_olap.sql` |
| 35 source columns preserved and validated | `src/synthesizer/generate.py`; `STG_HR_EMPLOYEE` in `02_staging.sql`; `tests/test_synthesizer.py` |
| 100,000+ reproducible snapshots, unique synthetic identities | `src/synthesizer/generate.py`; `docs/synthetic_data_policy.md` |
| Synthetic history with current row and effective intervals | `employee_history.csv` output from `generate.py`; `STG_EMPLOYEE_HISTORY`; `sp_load_olap_from_staging` |
| Batch audit and orchestration | `ETL_BATCH_LOG`; `src/etl/orchestrator.py` |
| SCD Type 2 and application updates | `DIM_EMPLOYEE`; `database/procedures/01_load_olap.sql`; `02_sync_employee_scd.sql`; `EmployeeRepository.update_tracked` |
| Surrogate dimensions, date dimension, review fact | `database/ddl/03_olap.sql`; `database/procedures/01_load_olap.sql`; `03_sync_review_fact.sql` |
| Stored procedures, CTEs, window functions | `database/procedures/`; `database/queries/cte_window_cleaning.sql`; `analytics.sql` |
| OOP entities and layered CRUD | `src/entities/`, `src/repository/`, `src/service/`, `src/controller/`, `frontend/app.py` |
| Dashboard, top-ranked employees, attrition exploration, project bottlenecks | `src/repository/analytics_repository.py`; Streamlit dashboard in `frontend/app.py` |
| Business validation | `src/validators/business.py`; `tests/test_business_rules.py` |
| Local setup and troubleshooting | `README.md`; `scripts/install_dependencies.ps1` |
| Git hygiene and no embedded credentials | `.gitignore`, `.env.example`, `src/config.py` |

MySQL integration depends on the local MySQL instance configured by the operator. The project targets local use only.
