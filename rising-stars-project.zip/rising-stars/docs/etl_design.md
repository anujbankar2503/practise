# ETL design

1. `generate.py` validates the exact source header, missing values, source identity uniqueness, and bounds; it writes reproducible 100,000+ row snapshots plus synthetic histories, projects, and review events.
2. `ETLOrchestrator` creates an `ETL_BATCH_LOG` entry, bulk loads raw snapshot rows and history, synchronizes generated operational records, then invokes `sp_load_olap_from_staging`.
3. The procedure loads department/project dimensions, upserts SCD employee versions using `employee_id` plus effective start date idempotency, creates date members for review dates, and resolves facts using the inclusive start/exclusive end rule.
4. Errors roll back work, leave the batch marked `FAILED`, and are logged without printing connection credentials. Batch counts are maintained for rows read and loaded; row-level validation rejects are surfaced as actionable errors before bulk load.

The IBM rating is a snapshot attribute. Dated application reviews and review scores are generated independently. The warehouse uses unique `review_id` for idempotent fact load. `DENSE_RANK()` and CTEs are in `database/queries/`.
