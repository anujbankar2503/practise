# Data dictionary and source mapping

The IBM source contains 35 columns: `Age`, `Attrition`, `BusinessTravel`, `DailyRate`, `Department`, `DistanceFromHome`, `Education`, `EducationField`, `EmployeeCount`, `EmployeeNumber`, `EnvironmentSatisfaction`, `Gender`, `HourlyRate`, `JobInvolvement`, `JobLevel`, `JobRole`, `JobSatisfaction`, `MaritalStatus`, `MonthlyIncome`, `MonthlyRate`, `NumCompaniesWorked`, `Over18`, `OverTime`, `PercentSalaryHike`, `PerformanceRating`, `RelationshipSatisfaction`, `StandardHours`, `StockOptionLevel`, `TotalWorkingYears`, `TrainingTimesLastYear`, `WorkLifeBalance`, `YearsAtCompany`, `YearsInCurrentRole`, `YearsSinceLastPromotion`, and `YearsWithCurrManager`.

| Source / generated value | Staging | OLTP | OLAP |
|---|---|---|---|
| IBM `EmployeeNumber` | `source_employee_number`, original `EmployeeNumber` | No operational key is inferred from it | `employee_number` is the generated business identifier; source ID lineage remains in staging |
| Generated stable identity | `synthetic_employee_number` | `EMPLOYEES.employee_number` | `DIM_EMPLOYEE.employee_number` |
| IBM `Department` | `Department` | matched to `DEPARTMENTS.department_name` | SCD department business ID in `DIM_EMPLOYEE.department_id`; star key in `DIM_DEPARTMENT.department_key` |
| IBM HR snapshot fields | 35 unchanged columns | mapped to compatible current HR attributes | descriptive employee attributes, current version |
| Synthesized names and hire date | additional `synthetic_first_name`, `synthetic_last_name`, `synthetic_hire_date` | operational employee fields | employee dimension attributes and `start_date` |
| Generated effective-dated changes | `STG_EMPLOYEE_HISTORY` | current state in `EMPLOYEES` | versions in `DIM_EMPLOYEE` with `employee_key` |
| Generated dated review event | generated review CSV / operational `REVIEWS` | review event | one row in `FACT_PERFORMANCE_REVIEWS` |

The IBM source snapshot does not contain actual employee names, hire dates, location fields, projects, assignments, review dates, or historical changes. Generated values are synthetic examples, labeled and kept separate from source facts. IBM `PerformanceRating` remains a source snapshot attribute and is not copied into dated review events.
