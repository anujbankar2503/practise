from src.service.employee_service import EmployeeService
from src.service.project_service import ProjectService
from src.service.assignment_service import AssignmentService
from src.service.review_service import ReviewService
from src.service.analytics_service import AnalyticsService


class AppController:
    """Frontend-facing orchestration; business rules remain in service classes."""
    def __init__(self):
        self.employees, self.projects = EmployeeService(), ProjectService()
        self.assignments, self.reviews, self.analytics = AssignmentService(), ReviewService(), AnalyticsService()
