"""Audited MySQL staging load and stored-procedure orchestration."""
import logging
import os
from pathlib import Path

import pandas as pd

from src.config import settings
from src.db.db_manager import DatabaseConnection

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("rising_stars.etl")


class ETLOrchestrator:
    def __init__(self): self.db = DatabaseConnection()

    def load_generated(self, directory: str | None = None) -> int:
        root = Path(directory or settings.synthetic_output_dir)
        employees = pd.read_csv(root / "employees.csv")
        history_path = root / "employee_history.csv"
        history = pd.read_csv(history_path).where(pd.notna(pd.read_csv(history_path)), None) if history_path.exists() else pd.DataFrame()
        conn = self.db.connect(settings.staging_database)
        batch_id = None
        try:
            cur = conn.cursor()
            cur.execute("INSERT INTO ETL_BATCH_LOG(source_name,load_started_at,load_status,rows_read) VALUES (%s,NOW(),'RUNNING',%s)", ("generated_ibm_snapshot", len(employees)))
            batch_id = cur.lastrowid
            columns = list(employees.columns)
            # Staging preserves the original 35 IBM fields in their native names.
            source_cols = columns[4:-2]  # all original IBM fields, unchanged
            sqlcols = ",".join(f"`{c}`" for c in source_cols)
            placeholders = ",".join(["%s"] * (len(source_cols) + 6))
            insert = f"INSERT INTO STG_HR_EMPLOYEE(batch_id,source_employee_number,synthetic_employee_number,synthetic_first_name,synthetic_last_name,synthetic_hire_date,{sqlcols},loaded_at) VALUES ({placeholders},NOW())"
            rows = []
            for rec in employees.to_dict("records"):
                rows.append((batch_id, int(rec["SourceEmployeeNumber"]), rec["SyntheticEmployeeNumber"], rec["FirstName"], rec["LastName"], rec["SyntheticHireDate"], *[rec[c] for c in source_cols]))
            cur.executemany(insert, rows)
            # History includes one current version for every synthetic identity and optional prior versions.
            history = pd.read_csv(root / "employee_history.csv")
            history = history.where(pd.notna(history), None)
            history_rows = [(batch_id, int(r.source_employee_number), r.synthetic_employee_number, r.department, r.job_role, int(r.job_level) if r.job_level is not None else None, float(r.monthly_income) if r.monthly_income is not None else None, r.effective_start_date, None if pd.isna(r.effective_end_date) else r.effective_end_date, bool(r.is_current), r.change_reason) for r in history.itertuples(index=False)]
            cur.executemany("INSERT INTO STG_EMPLOYEE_HISTORY(batch_id,source_employee_number,synthetic_employee_number,department,job_role,job_level,monthly_income,effective_start_date,effective_end_date,is_current,change_reason,loaded_at) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW())", history_rows)
            reviews = pd.read_csv(root / "reviews.csv")
            reviews = reviews.where(pd.notna(reviews), None)
            cur.executemany("INSERT INTO STG_SYNTHETIC_REVIEW(batch_id,synthetic_event_key,synthetic_employee_number,project_code,review_date,performance_rating,performance_score) VALUES(%s,%s,%s,%s,%s,%s,%s)", [(batch_id,r.review_token,r.synthetic_employee_number,r.project_code,r.review_date,int(r.performance_rating),float(r.performance_score)) for r in reviews.itertuples(index=False)])
            assignments = pd.read_csv(root / "assignments.csv")
            assignments = assignments.where(pd.notna(assignments), None)
            cur.executemany("INSERT INTO STG_SYNTHETIC_ASSIGNMENT(batch_id,synthetic_assignment_key,synthetic_employee_number,project_code,start_date,end_date,billable_flag,allocation_percentage) VALUES(%s,%s,%s,%s,%s,%s,%s,%s)", [(batch_id,r.assignment_token,r.synthetic_employee_number,r.project_code,r.start_date,None if pd.isna(r.end_date) else r.end_date,bool(r.billable_flag),float(r.allocation_percentage)) for r in assignments.itertuples(index=False)])
            # Generated project/review events are separate from IBM snapshot performance ratings.
            projects = pd.read_csv(root / "projects.csv").where(pd.notna(pd.read_csv(root / "projects.csv")), None)
            cur.execute("SELECT 1")
            oltp = self.db.connect(settings.oltp_database)
            try:
                pc = oltp.cursor()
                pc.executemany("INSERT INTO rising_stars_oltp.PROJECTS(project_code,project_name,project_status,project_start_date,planned_end_date,actual_end_date) VALUES(%s,%s,%s,%s,%s,NULL) ON DUPLICATE KEY UPDATE project_name=VALUES(project_name),project_status=VALUES(project_status)", [(r.project_code,r.project_name,r.project_status,r.project_start_date,r.planned_end_date) for r in projects.itertuples(index=False)])
                pc.executemany("INSERT INTO rising_stars_oltp.DEPARTMENTS(department_name,department_code,is_active) VALUES(%s,%s,TRUE) ON DUPLICATE KEY UPDATE department_name=VALUES(department_name)", [(str(d), str(d).upper().replace(' ','_')[:20]) for d in employees.Department.unique()])
                oltp.commit()
            except Exception:
                oltp.rollback(); raise
            finally: oltp.close()
            conn.commit()
            cur.execute("CALL sp_load_olap_from_staging(%s)", (batch_id,))
            cur.execute("UPDATE ETL_BATCH_LOG SET load_status='SUCCESS',load_completed_at=NOW(),rows_loaded=%s,rows_rejected=0 WHERE batch_id=%s", (len(employees), batch_id))
            conn.commit()
            log.info("Batch %s completed: %s rows loaded", batch_id, len(employees))
            return int(batch_id)
        except Exception as exc:
            conn.rollback()
            if batch_id is not None:
                try:
                    cur.execute("UPDATE ETL_BATCH_LOG SET load_status='FAILED',load_completed_at=NOW(),error_message=%s WHERE batch_id=%s", (str(exc)[:2000], batch_id)); conn.commit()
                except Exception: conn.rollback()
            log.exception("ETL failed for batch %s", batch_id)
            raise
        finally: conn.close()


if __name__ == "__main__":
    batch = ETLOrchestrator().load_generated()
    print(f"Loaded batch {batch}")
