from src.repository.assignment_repository import AssignmentRepository
from src.validators.business import validate_assignment


class AssignmentService:
    def __init__(self, repository=None): self.repository = repository or AssignmentRepository()
    def list(self): return self.repository.list()
    def create(self, fields):
        validate_assignment(fields["allocation_percentage"], fields["start_date"], fields.get("end_date"))
        return self.repository.create(fields)
