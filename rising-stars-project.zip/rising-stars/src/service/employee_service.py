from src.entities import Employee
from src.repository.employee_repository import EmployeeRepository


class EmployeeService:
    def __init__(self, repository=None):
        self.repository = repository or EmployeeRepository()

    def browse(self, search="", department_id=None, limit=500):
        return self.repository.list(search, department_id, limit)

    def onboard(self, employee: Employee):
        if employee.monthly_income < 0:
            raise ValueError("Monthly income cannot be negative.")
        return self.repository.create(employee.__dict__)

    def update_tracked(self, employee_id, department_id, job_role, job_level, monthly_income):
        if monthly_income < 0:
            raise ValueError("Monthly income cannot be negative.")
        self.repository.update_tracked(employee_id, department_id, job_role, job_level, monthly_income)
