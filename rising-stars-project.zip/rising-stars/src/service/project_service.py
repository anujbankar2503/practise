from src.repository.project_repository import ProjectRepository
from src.validators.business import validate_project


class ProjectService:
    def __init__(self, repository=None): self.repository = repository or ProjectRepository()
    def list(self): return self.repository.list()
    def create(self, fields):
        validate_project(fields["project_status"], fields["project_start_date"], fields.get("planned_end_date"), fields.get("actual_end_date"))
        return self.repository.create(fields)
