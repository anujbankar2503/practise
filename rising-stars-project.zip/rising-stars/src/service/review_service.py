from src.repository.review_repository import ReviewRepository
from src.validators.business import validate_review


class ReviewService:
    def __init__(self, repository=None): self.repository = repository or ReviewRepository()
    def list(self, department_id=None, project_id=None): return self.repository.list(department_id, project_id)
    def create(self, fields):
        validate_review(fields.get("performance_rating"), fields.get("performance_score"))
        return self.repository.create(fields)
