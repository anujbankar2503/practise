from src.repository.analytics_repository import AnalyticsRepository


class AnalyticsService:
    def __init__(self, repository=None): self.repository = repository or AnalyticsRepository()
    def dashboard(self, department_id=None, project_id=None): return self.repository.dashboard(department_id, project_id)
