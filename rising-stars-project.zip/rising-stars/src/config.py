from dataclasses import dataclass
import os

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    mysql_host: str = os.getenv("MYSQL_HOST", "127.0.0.1")
    mysql_port: int = int(os.getenv("MYSQL_PORT", "3306"))
    mysql_user: str = os.getenv("MYSQL_USER", "rising_stars_app")
    mysql_password: str = os.getenv("MYSQL_PASSWORD", "")
    oltp_database: str = os.getenv("OLTP_DATABASE", "rising_stars_oltp")
    staging_database: str = os.getenv("STAGING_DATABASE", "rising_stars_staging")
    olap_database: str = os.getenv("OLAP_DATABASE", "rising_stars_olap")
    batch_size: int = int(os.getenv("BATCH_SIZE", "1000"))
    source_csv: str = os.getenv("SOURCE_CSV", "data/WA_Fn-UseC_-HR-Employee-Attrition.csv")
    synthetic_output_dir: str = os.getenv("SYNTHETIC_OUTPUT_DIR", "data/generated")


settings = Settings()
