from contextlib import contextmanager
from threading import RLock
from typing import Iterator

from src.config import settings


class DatabaseConnection:
    """Thread-safe lazy Singleton for MySQL connections; one short-lived connection per unit of work."""

    _instance = None
    _lock = RLock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
            return cls._instance

    def connect(self, database: str | None = None):
        try:
            import mysql.connector
        except ImportError as exc:
            raise RuntimeError("MySQL connector is missing. Run the local dependency installer in scripts/.") from exc
        if not settings.mysql_password:
            raise RuntimeError("Set MYSQL_PASSWORD in the local .env file.")
        allowed = {settings.oltp_database, settings.staging_database, settings.olap_database}
        if database is not None and database not in allowed:
            raise ValueError("Database name is not in the configured schema allowlist.")
        return mysql.connector.connect(
            host=settings.mysql_host, port=settings.mysql_port,
            user=settings.mysql_user, password=settings.mysql_password,
            database=database, autocommit=False, connection_timeout=10,
        )

    @contextmanager
    def transaction(self, database: str) -> Iterator:
        connection = self.connect(database)
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()
