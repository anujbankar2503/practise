from src.repository.base import Repository


class AssignmentRepository(Repository):
    def list(self) -> list[dict]:
        return self.query("SELECT a.assignment_id, e.employee_number, CONCAT(e.first_name,' ',e.last_name) employee_name, p.project_code, p.project_name, a.start_date, a.end_date, a.allocation_percentage, a.billable_flag FROM ASSIGNMENTS a JOIN EMPLOYEES e USING(employee_id) JOIN PROJECTS p USING(project_id) ORDER BY a.start_date DESC")

    def create(self, f: dict) -> int:
        return self.execute("INSERT INTO ASSIGNMENTS (employee_id, project_id, start_date, end_date, billable_flag, allocation_percentage) VALUES (%s,%s,%s,%s,%s,%s)", (f["employee_id"], f["project_id"], f["start_date"], f.get("end_date"), f["billable_flag"], f["allocation_percentage"]))
