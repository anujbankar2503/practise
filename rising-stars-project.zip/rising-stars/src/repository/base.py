from src.config import settings
from src.db.db_manager import DatabaseConnection


class Repository:
    def __init__(self, database: str | None = None):
        self.database = database or settings.oltp_database
        self.db = DatabaseConnection()

    def query(self, sql: str, params: tuple = ()) -> list[dict]:
        connection = self.db.connect(self.database)
        try:
            cursor = connection.cursor(dictionary=True)
            cursor.execute(sql, params)
            return list(cursor.fetchall())
        finally:
            connection.close()

    def execute(self, sql: str, params: tuple = ()) -> int:
        with self.db.transaction(self.database) as connection:
            cursor = connection.cursor()
            cursor.execute(sql, params)
            return cursor.lastrowid
