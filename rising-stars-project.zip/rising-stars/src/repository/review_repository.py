from src.repository.base import Repository


class ReviewRepository(Repository):
    def list(self, department_id: int | None = None, project_id: int | None = None) -> list[dict]:
        where, params = [], []
        if department_id is not None:
            where.append("e.department_id=%s"); params.append(department_id)
        if project_id is not None:
            where.append("r.project_id=%s"); params.append(project_id)
        clause = (" WHERE " + " AND ".join(where)) if where else ""
        return self.query("SELECT r.*, CONCAT(e.first_name,' ',e.last_name) employee_name, e.department_id FROM REVIEWS r JOIN EMPLOYEES e ON e.employee_id=r.employee_id" + clause + " ORDER BY r.review_date DESC LIMIT 1000", tuple(params))

    def create(self, f: dict) -> int:
        with self.db.transaction(self.database) as connection:
            cursor=connection.cursor()
            status="Pending" if f.get("performance_rating") is None else "Completed"
            cursor.execute("INSERT INTO REVIEWS (reviewer_employee_id, employee_id, project_id, review_date, performance_rating, performance_score, review_status, comments) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)", (f.get("reviewer_employee_id"), f["employee_id"], f.get("project_id"), f["review_date"], f.get("performance_rating"), f.get("performance_score"),status, f.get("comments")))
            review_id=cursor.lastrowid
            cursor.execute("CALL rising_stars_olap.sp_sync_review_fact(%s)",(review_id,))
            cursor.execute("SELECT COUNT(*) FROM rising_stars_olap.FACT_PERFORMANCE_REVIEWS WHERE review_id=%s",(review_id,))
            if cursor.fetchone()[0] != 1:
                raise ValueError("Review date does not fall within a known employee history interval.")
            return review_id
