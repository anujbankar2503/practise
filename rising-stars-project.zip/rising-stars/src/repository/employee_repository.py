from src.repository.base import Repository


class EmployeeRepository(Repository):
    def list(self, search: str = "", department_id: int | None = None, limit: int = 500) -> list[dict]:
        where = ["(%s = '' OR CONCAT(e.first_name, ' ', e.last_name, ' ', e.employee_number) LIKE CONCAT('%', %s, '%'))"]
        params: list = [search, search]
        if department_id is not None:
            where.append("e.department_id = %s")
            params.append(department_id)
        params.append(limit)
        return self.query(f"SELECT e.*, d.department_name FROM EMPLOYEES e JOIN DEPARTMENTS d USING(department_id) WHERE {' AND '.join(where)} ORDER BY e.last_name, e.first_name LIMIT %s", tuple(params))

    def departments(self) -> list[dict]:
        return self.query("SELECT department_id, department_name, department_code FROM DEPARTMENTS WHERE is_active=TRUE ORDER BY department_name")

    def create(self, fields: dict) -> int:
        with self.db.transaction(self.database) as connection:
            cursor=connection.cursor()
            cursor.execute("INSERT INTO EMPLOYEES (employee_number, department_id, first_name, last_name, hire_date, job_role, job_level, gender, monthly_income, age) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", (fields["employee_number"], fields["department_id"], fields["first_name"], fields["last_name"], fields["hire_date"], fields["job_role"], fields.get("job_level"), fields.get("gender"), fields["monthly_income"], fields.get("age")))
            employee_id=cursor.lastrowid
            cursor.execute("CALL rising_stars_olap.sp_sync_employee_scd(%s)",(employee_id,))
            return employee_id

    def update_tracked(self, employee_id: int, department_id: int, job_role: str, job_level: int | None, monthly_income: float) -> None:
        with self.db.transaction(self.database) as conn:
            cur = conn.cursor()
            cur.execute("SELECT employee_id FROM EMPLOYEES WHERE employee_id=%s FOR UPDATE", (employee_id,))
            if not cur.fetchone():
                raise ValueError("Employee does not exist.")
            cur.execute("UPDATE EMPLOYEES SET department_id=%s, job_role=%s, job_level=%s, monthly_income=%s WHERE employee_id=%s", (department_id, job_role, job_level, monthly_income, employee_id))
            cur.execute("CALL rising_stars_olap.sp_sync_employee_scd(%s)", (employee_id,))

