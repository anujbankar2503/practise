from src.repository.base import Repository


class ProjectRepository(Repository):
    def list(self) -> list[dict]:
        return self.query("SELECT * FROM PROJECTS ORDER BY project_start_date DESC")

    def create(self, f: dict) -> int:
        return self.execute("INSERT INTO PROJECTS (project_code, project_name, project_status, project_start_date, planned_end_date, actual_end_date) VALUES (%s,%s,%s,%s,%s,%s)", (f["project_code"], f["project_name"], f["project_status"], f["project_start_date"], f.get("planned_end_date"), f.get("actual_end_date")))
