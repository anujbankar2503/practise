from src.config import settings
from src.repository.base import Repository


class AnalyticsRepository(Repository):
    def __init__(self):
        super().__init__(settings.olap_database)

    def dashboard(self, department_id: int | None = None, project_id: int | None = None) -> dict:
        conditions, args = [], []
        if department_id is not None: conditions.append("f.department_key=%s"); args.append(department_id)
        if project_id is not None: conditions.append("f.project_key=%s"); args.append(project_id)
        filt = " WHERE " + " AND ".join(conditions) if conditions else ""
        params=tuple(args)
        metrics = self.query("SELECT COUNT(DISTINCT e.employee_id) employees, COUNT(DISTINCT f.review_id) reviews, ROUND(AVG(f.performance_score),1) avg_score, COUNT(DISTINCT f.project_key) projects FROM FACT_PERFORMANCE_REVIEWS f JOIN DIM_EMPLOYEE e USING(employee_key)" + filt, params)
        trend = self.query("SELECT d.year, ROUND(AVG(f.performance_score),2) average_score, SUM(f.review_count) reviews FROM FACT_PERFORMANCE_REVIEWS f JOIN DIM_DATE d ON d.date_key=f.review_date_key" + filt + " GROUP BY d.year ORDER BY d.year", params)
        top = self.query("SELECT department_name, employee_id, employee_name, average_score, DENSE_RANK() OVER(PARTITION BY department_key ORDER BY average_score DESC) department_rank FROM (SELECT de.department_key, de.department_name, e.employee_id, CONCAT(e.first_name,' ',e.last_name) employee_name, AVG(f.performance_score) average_score FROM FACT_PERFORMANCE_REVIEWS f JOIN DIM_EMPLOYEE e USING(employee_key) JOIN DIM_DEPARTMENT de USING(department_key) GROUP BY de.department_key,de.department_name,e.employee_id,e.first_name,e.last_name) ranked ORDER BY department_name,department_rank LIMIT 100")
        attrition = self.query("SELECT d.department_name department,e.overtime,COUNT(*) employees,SUM(e.attrition_status='Yes') left_count,ROUND(100*AVG(e.attrition_status='Yes'),1) attrition_pct FROM DIM_EMPLOYEE e JOIN DIM_DEPARTMENT d ON d.department_id=e.department_id WHERE e.is_current=TRUE GROUP BY d.department_name,e.overtime ORDER BY attrition_pct DESC")
        bottlenecks = self.query("SELECT p.project_name, COUNT(DISTINCT f.employee_key) reviewed_employees, ROUND(AVG(f.performance_score),1) average_score FROM FACT_PERFORMANCE_REVIEWS f JOIN DIM_PROJECT p USING(project_key) GROUP BY p.project_key,p.project_name ORDER BY reviewed_employees DESC")
        allocation = self.query("SELECT p.project_name,COUNT(DISTINCT a.employee_id) assigned_employees,ROUND(SUM(CASE WHEN a.end_date IS NULL OR a.end_date>=CURRENT_DATE THEN a.allocation_percentage ELSE 0 END),1) active_allocation_pct FROM rising_stars_oltp.ASSIGNMENTS a JOIN rising_stars_oltp.PROJECTS p USING(project_id) GROUP BY p.project_id,p.project_name ORDER BY active_allocation_pct DESC")
        overloaded = self.query("SELECT e.employee_id,e.employee_number,CONCAT(e.first_name,' ',e.last_name) employee_name,SUM(a.allocation_percentage) active_allocation_pct FROM rising_stars_oltp.EMPLOYEES e JOIN rising_stars_oltp.ASSIGNMENTS a USING(employee_id) WHERE a.end_date IS NULL OR a.end_date>=CURRENT_DATE GROUP BY e.employee_id,e.employee_number,e.first_name,e.last_name HAVING SUM(a.allocation_percentage)>100 ORDER BY active_allocation_pct DESC LIMIT 100")
        latest = self.query("SELECT batch_id, load_status, load_completed_at, rows_loaded, rows_rejected FROM rising_stars_staging.ETL_BATCH_LOG ORDER BY batch_id DESC LIMIT 1")
        return {"metrics": (metrics or [{}])[0], "trend": trend, "top": top, "attrition": attrition, "bottlenecks": bottlenecks, "allocation":allocation,"overloaded":overloaded,"latest": latest}

