from datetime import date

PROJECT_STATUSES = {"Planned", "Active", "Completed", "Cancelled"}


def validate_project(status: str, start: date, planned_end: date | None, actual_end: date | None) -> None:
    if status not in PROJECT_STATUSES:
        raise ValueError("Project status must be Planned, Active, Completed, or Cancelled.")
    if planned_end and planned_end < start:
        raise ValueError("Planned end date must be on or after the start date.")
    if actual_end and actual_end < start:
        raise ValueError("Actual end date must be on or after the start date.")


def validate_assignment(allocation: int, start: date, end: date | None) -> None:
    if not 0 <= allocation <= 100:
        raise ValueError("Allocation percentage must be between 0 and 100.")
    if end and end < start:
        raise ValueError("Assignment end date must be on or after its start date.")


def validate_review(rating: int | None, score: float | None) -> None:
    if rating is not None and not 1 <= rating <= 5:
        raise ValueError("Review rating must be between 1 and 5.")
    if score is not None and not 0 <= score <= 100:
        raise ValueError("Review score must be between 0 and 100.")
