from dataclasses import dataclass
from datetime import date
from decimal import Decimal


@dataclass
class Employee:
    employee_number: str
    first_name: str
    last_name: str
    department_id: int
    hire_date: date
    job_role: str
    monthly_income: Decimal
    job_level: int | None = None
    gender: str | None = None
    age: int | None = None
    employee_id: int | None = None


@dataclass
class Project:
    project_code: str
    project_name: str
    start_date: date
    project_status: str = "Planned"
    planned_end_date: date | None = None
    actual_end_date: date | None = None
    project_id: int | None = None


@dataclass
class Review:
    employee_id: int
    review_date: date
    performance_rating: int | None = None
    performance_score: Decimal | None = None
    project_id: int | None = None
    reviewer_employee_id: int | None = None
    comments: str | None = None
    review_id: int | None = None
