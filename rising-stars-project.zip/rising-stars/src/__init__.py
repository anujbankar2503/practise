"""Rising Stars employee analytics application."""
