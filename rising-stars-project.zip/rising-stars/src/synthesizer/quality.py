"""Database-independent checks for generated CSV artifacts."""
import argparse
from pathlib import Path

import pandas as pd

from src.synthesizer.generate import load_source


def validate_generated(directory: str | Path, source_csv: str) -> dict[str, int]:
    root=Path(directory); source=load_source(source_csv)
    employees=pd.read_csv(root/"employees.csv")
    if len(employees)<100_000: raise ValueError("Generated employee count is below 100,000.")
    if not employees.SyntheticEmployeeNumber.is_unique: raise ValueError("Synthetic employee identities are not unique.")
    if not set(employees.SourceEmployeeNumber).issubset(set(source.EmployeeNumber)): raise ValueError("Synthetic-to-source identity lineage contains unknown source IDs.")
    if employees["SyntheticRecord"].ne(True).any(): raise ValueError("Synthetic snapshot marker is missing.")
    history=pd.read_csv(root/"employee_history.csv")
    current=history[history.is_current.astype(bool)]
    counts=current.groupby("synthetic_employee_number").size()
    if set(counts.index)!=set(employees.SyntheticEmployeeNumber) or not counts.eq(1).all(): raise ValueError("Every employee must have exactly one current history row.")
    if current.effective_end_date.notna().any(): raise ValueError("Current history rows must have a null end date.")
    historical=history[~history.is_current.astype(bool)]
    if historical.effective_end_date.isna().any(): raise ValueError("Historical rows require an end date.")
    for identity, group in history.sort_values("effective_start_date").groupby("synthetic_employee_number"):
        rows=list(group.itertuples(index=False))
        for earlier,later in zip(rows,rows[1:]):
            if pd.Timestamp(earlier.effective_end_date)>pd.Timestamp(later.effective_start_date):
                raise ValueError(f"Overlapping history intervals for {identity}.")
            if pd.Timestamp(earlier.effective_start_date)>=pd.Timestamp(later.effective_start_date):
                raise ValueError(f"History intervals are not strictly ordered for {identity}.")
    assignments=pd.read_csv(root/"assignments.csv")
    if not assignments.allocation_percentage.between(0,100).all(): raise ValueError("Assignment allocation outside 0-100.")
    reviews=pd.read_csv(root/"reviews.csv")
    if not reviews.performance_rating.between(1,5).all() or not reviews.performance_score.between(0,100).all(): raise ValueError("Generated review rating/score out of bounds.")
    return {"employees":len(employees),"history_rows":len(history),"assignments":len(assignments),"reviews":len(reviews)}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory",default="data/generated")
    parser.add_argument("--source",default="data/WA_Fn-UseC_-HR-Employee-Attrition.csv")
    args=parser.parse_args()
    print(validate_generated(args.directory,args.source))


if __name__=="__main__": main()
