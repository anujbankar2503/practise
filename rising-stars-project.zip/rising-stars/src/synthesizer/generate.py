"""Generate repeatable synthetic snapshots and clearly marked synthetic event history."""
import argparse
import os
from pathlib import Path

import pandas as pd
from faker import Faker

EXPECTED_COLUMNS = ["Age", "Attrition", "BusinessTravel", "DailyRate", "Department", "DistanceFromHome", "Education", "EducationField", "EmployeeCount", "EmployeeNumber", "EnvironmentSatisfaction", "Gender", "HourlyRate", "JobInvolvement", "JobLevel", "JobRole", "JobSatisfaction", "MaritalStatus", "MonthlyIncome", "MonthlyRate", "NumCompaniesWorked", "Over18", "OverTime", "PercentSalaryHike", "PerformanceRating", "RelationshipSatisfaction", "StandardHours", "StockOptionLevel", "TotalWorkingYears", "TrainingTimesLastYear", "WorkLifeBalance", "YearsAtCompany", "YearsInCurrentRole", "YearsSinceLastPromotion", "YearsWithCurrManager"]


def load_source(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    if list(df.columns) != EXPECTED_COLUMNS:
        missing = sorted(set(EXPECTED_COLUMNS) - set(df.columns)); extra = sorted(set(df.columns) - set(EXPECTED_COLUMNS))
        raise ValueError(f"IBM CSV schema mismatch. Missing={missing}; extra={extra}")
    if df.isna().any().any():
        raise ValueError("Source CSV contains missing values; inspect source before synthesis.")
    if df.EmployeeNumber.duplicated().any():
        raise ValueError("Source EmployeeNumber must be unique.")
    if not df.Age.between(18, 100).all() or not df.MonthlyIncome.ge(0).all():
        raise ValueError("Source age or monthly income is outside allowed bounds.")
    return df


def synthesize(source_path: str, output: str, target: int = 100_000, seed: int = 42) -> dict[str, int]:
    if target < 100_000:
        raise ValueError("Target must be at least 100000 employees.")
    base = load_source(source_path)
    faker = Faker(); Faker.seed(seed)
    rng = __import__("numpy").random.default_rng(seed)
    sample = rng.integers(0, len(base), size=target)
    employees = base.iloc[sample].reset_index(drop=True).copy()
    source_ids = base.EmployeeNumber.to_numpy()
    selected_source_ids = source_ids[sample]
    employees.insert(0, "SyntheticEmployeeNumber", [f"SYN-{i+1:07d}" for i in range(target)])
    employees.insert(1, "SourceEmployeeNumber", selected_source_ids)
    employees.insert(2, "FirstName", [faker.first_name() for _ in range(target)])
    employees.insert(3, "LastName", [faker.last_name() for _ in range(target)])
    # Dates and events below are explicitly synthetic; they are never treated as IBM source facts.
    hires = pd.to_datetime(pd.Series(rng.integers(pd.Timestamp("2010-01-01").value // 10**9, pd.Timestamp("2021-01-01").value // 10**9, target), unit="s")).dt.normalize()
    employees["SyntheticHireDate"] = hires.dt.date.astype(str)
    employees["SyntheticRecord"] = True
    out = Path(output); out.mkdir(parents=True, exist_ok=True)
    employees.to_csv(out / "employees.csv", index=False)

    # Generate effective-dated timelines for a reproducible subset. Current version is end-exclusive.
    changed = rng.choice(target, size=max(1, int(target * 0.15)), replace=False)
    history = []
    changed_set = set(int(x) for x in changed)
    for idx in range(target):
        row = employees.iloc[idx]
        if idx not in changed_set:
            history.append({"synthetic_employee_number": row.SyntheticEmployeeNumber, "source_employee_number": int(row.SourceEmployeeNumber), "department": row.Department, "job_role": row.JobRole, "job_level": int(row.JobLevel), "monthly_income": float(row.MonthlyIncome), "effective_start_date": pd.Timestamp(row.SyntheticHireDate).isoformat(), "effective_end_date": None, "is_current": True, "change_reason": "SYNTHETIC_INITIAL_SNAPSHOT"})
    for idx in changed:
        row = employees.iloc[idx]
        start = pd.Timestamp(row.SyntheticHireDate)
        change = min(start + pd.Timedelta(days=int(rng.integers(365, 1800))), pd.Timestamp("2024-01-01"))
        old_dept = row.Department
        new_dept = rng.choice(base.Department.unique()) if rng.random() < .35 else old_dept
        old_role = row.JobRole
        new_role = rng.choice(base.JobRole.unique()) if rng.random() < .30 else old_role
        salary = float(row.MonthlyIncome)
        history.extend([
            {"synthetic_employee_number": row.SyntheticEmployeeNumber, "source_employee_number": int(row.SourceEmployeeNumber), "department": old_dept, "job_role": old_role, "job_level": int(row.JobLevel), "monthly_income": salary, "effective_start_date": start.isoformat(), "effective_end_date": change.isoformat(), "is_current": False, "change_reason": "SYNTHETIC_PRE_CHANGE"},
            {"synthetic_employee_number": row.SyntheticEmployeeNumber, "source_employee_number": int(row.SourceEmployeeNumber), "department": new_dept, "job_role": new_role, "job_level": min(5, int(row.JobLevel) + int(new_role != old_role)), "monthly_income": round(salary * (1 + float(rng.uniform(.03, .18))), 2), "effective_start_date": change.isoformat(), "effective_end_date": None, "is_current": True, "change_reason": "SYNTHETIC_TRANSFER_PROMOTION_OR_RAISE"},
        ])
    pd.DataFrame(history).to_csv(out / "employee_history.csv", index=False)
    project_names = ["Atlas", "Beacon", "Cedar", "Drift", "Evergreen", "Frontier", "Horizon", "Ion", "Juniper", "Keystone"]
    project_rows = [{"project_code": f"SYN-P{i+1:03d}", "project_name": f"{name} Initiative", "project_status": "Active", "project_start_date": "2022-01-01", "planned_end_date": "2027-12-31", "actual_end_date": "", "synthetic_record": True} for i, name in enumerate(project_names)]
    pd.DataFrame(project_rows).to_csv(out / "projects.csv", index=False)
    assignment_rows = []
    for i in range(target):
        if rng.random() < .35:
            start = pd.Timestamp("2023-01-01") + pd.Timedelta(days=int(rng.integers(0, 800)))
            assignment_rows.append({"assignment_token": f"SYN-A-{i+1:07d}", "synthetic_employee_number": employees.iloc[i].SyntheticEmployeeNumber, "project_code": project_rows[int(rng.integers(0,len(project_rows)))]["project_code"], "start_date": start.date().isoformat(), "end_date": "", "billable_flag": bool(rng.random() < .7), "allocation_percentage": int(rng.choice([20,25,40,50,60,75,100])), "synthetic_record": True})
    pd.DataFrame(assignment_rows).to_csv(out / "assignments.csv", index=False)
    review_rows = []
    for i in range(target):
        if rng.random() < .65:
            review_date = pd.Timestamp("2024-01-01") + pd.Timedelta(days=int(rng.integers(0, 1000)))
            review_rows.append({"review_token": f"SYN-R-{i+1:07d}", "synthetic_employee_number": employees.iloc[i].SyntheticEmployeeNumber, "project_code": project_rows[int(rng.integers(0, len(project_rows)))]["project_code"], "review_date": review_date.date().isoformat(), "performance_rating": int(rng.integers(1, 6)), "performance_score": round(float(rng.uniform(55, 100)), 2), "synthetic_record": True})
    pd.DataFrame(review_rows).to_csv(out / "reviews.csv", index=False)
    return {"source_rows": len(base), "employees": len(employees), "history_rows": len(history), "projects": len(project_rows), "assignments": len(assignment_rows), "reviews": len(review_rows)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", default=os.getenv("SOURCE_CSV", "data/WA_Fn-UseC_-HR-Employee-Attrition.csv"))
    parser.add_argument("--output", default=os.getenv("SYNTHETIC_OUTPUT_DIR", "data/generated"))
    parser.add_argument("--target", type=int, default=int(os.getenv("TARGET_EMPLOYEES", "100000")))
    parser.add_argument("--seed", type=int, default=int(os.getenv("RANDOM_SEED", "42")))
    args = parser.parse_args()
    print(synthesize(args.source, args.output, args.target, args.seed))


if __name__ == "__main__": main()
