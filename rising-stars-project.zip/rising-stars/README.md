# Rising Stars - Local Employee Analytics and Data Warehouse

This project runs locally with Streamlit at `http://localhost:8501` and MySQL 8 on this computer.

## Includes

- OLTP, staging, and OLAP MySQL schemas with stored procedures.
- Pandas/Faker synthesis for 100,000+ employee snapshots, effective-dated history, projects, assignments, and generated review events.
- Batch ETL, employee/project/review workflows, and a Streamlit/Plotly analytics dashboard.
- Tests, traceability documentation, data dictionary, and editable diagrams.net schemas.

Synthetic names, hire dates, assignments, history, and dated reviews are generated examples. The IBM CSV is a snapshot; its `PerformanceRating` is not treated as a dated review.

## Requirements

- CPython 3.12.
- MySQL Server 8.0.16+ running locally. On this machine the Windows service is `MySQL80`.
- Windows PowerShell.

## Setup

1. Install dependencies from this project folder:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\scripts\install_dependencies.ps1
   ```

   The installer uses a virtual environment under `%LOCALAPPDATA%\RisingStars\venv`, outside OneDrive. It uses a separate local temp folder, no pip cache, a 30-minute read timeout, and 20 retries. At the 9 KB/s rate in the previous log, pandas may need roughly 20 minutes; keep the installer running. It prints the exact `requirements.txt` it reads so a wrong project copy is obvious.

2. Copy `.env.example` to `.env` and set `MYSQL_HOST=127.0.0.1`, `MYSQL_PORT=3306`, MySQL username/password, and the three schema names:

   ```powershell
   Copy-Item .env.example .env
   ```

3. Initialize the local schemas in MySQL Workbench or run, in order:

   ```powershell
   cmd /c "mysql -u root -p < database\ddl\00_create_schemas.sql"
   cmd /c "mysql -u root -p < database\ddl\01_oltp.sql"
   cmd /c "mysql -u root -p < database\ddl\02_staging.sql"
   cmd /c "mysql -u root -p < database\ddl\03_olap.sql"
   cmd /c "mysql -u root -p < database\procedures\01_load_olap.sql"
   cmd /c "mysql -u root -p < database\procedures\02_sync_employee_scd.sql"
   cmd /c "mysql -u root -p < database\procedures\03_sync_review_fact.sql"
   ```

4. Generate data, load staging, and run the ETL:

   ```powershell
   $py = Join-Path $env:LOCALAPPDATA 'RisingStars\venv\Scripts\python.exe'
   & $py -m src.synthesizer.generate --source data/WA_Fn-UseC_-HR-Employee-Attrition.csv --output data/generated --target 100000 --seed 42
   & $py -m src.synthesizer.quality --directory data/generated --source data/WA_Fn-UseC_-HR-Employee-Attrition.csv
   & $py -m src.etl.orchestrator
   ```

5. Start the app and run tests:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\scripts\run_local.ps1
   $py = Join-Path $env:LOCALAPPDATA 'RisingStars\venv\Scripts\python.exe'
   & $py -m pytest -q
   ```

   Open `http://localhost:8501` on this computer. The server binds only to `127.0.0.1`.

## Layout

- `frontend/`: local Streamlit UI.
- `src/controller`, `src/service`, `src/repository`: application layers.
- `src/db`: local MySQL connection manager.
- `src/synthesizer`, `src/etl`: data generation and local warehouse loading.
- `database/`: MySQL DDL, procedures, analytical queries.
- `docs/diagrams`: editable OLTP, staging, and OLAP models.

## Troubleshooting

- **Still selects pandas 3.1:** you are using an older/different `requirements.txt`. Run the installer above and confirm its printed dependency list includes `pandas>=2.2,<3.0`; do not run bare `pip install -r requirements.txt`.
- **Downloads stall:** the previous log shows the timeout at `files.pythonhosted.org`, not an app connection. The installer raises the read timeout so pip can finish the large wheel without restarting every 15 seconds.
- **OneDrive file locking:** the active Python environment and pip temp downloads are kept in local `%LOCALAPPDATA%`, outside the synced project folder.
- **MySQL connection refused:** confirm `MySQL80` is running and `.env` points to `127.0.0.1:3306`.
- **MySQL access denied:** verify local credentials and schema permissions without pasting passwords into logs.
- **Empty dashboard:** run the schema scripts, synthesizer, and ETL first.

`DIM_EMPLOYEE` is SCD Type 2: `employee_key` is the surrogate key; start dates are inclusive and end dates exclusive; null end date means current. Attrition views are exploratory, not a prediction model.
