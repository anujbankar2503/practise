from datetime import date

import pytest

from src.validators.business import validate_assignment, validate_project, validate_review


def test_allocation_range_and_dates():
    validate_assignment(100, date(2025, 1, 1), None)
    with pytest.raises(ValueError): validate_assignment(101, date(2025, 1, 1), None)
    with pytest.raises(ValueError): validate_assignment(50, date(2025, 2, 1), date(2025, 1, 1))


def test_project_status_and_date_rules():
    validate_project("Active", date(2025, 1, 1), date(2025, 2, 1), None)
    with pytest.raises(ValueError): validate_project("Unallocated", date(2025, 1, 1), None, None)
    with pytest.raises(ValueError): validate_project("Planned", date(2025, 2, 1), date(2025, 1, 1), None)


def test_review_rating_score_rules():
    validate_review(None, None)  # pending review
    validate_review(5, 100)
    with pytest.raises(ValueError): validate_review(6, None)
    with pytest.raises(ValueError): validate_review(3, 101)
