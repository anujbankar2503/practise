import pandas as pd
import pytest

from src.synthesizer.generate import EXPECTED_COLUMNS, load_source


def test_source_schema_and_identifiers(tmp_path):
    row = {column: 1 for column in EXPECTED_COLUMNS}
    row.update({"Age":30,"Attrition":"No","BusinessTravel":"Travel_Rarely","Department":"Sales","EducationField":"Other","Gender":"Female","JobRole":"Manager","MaritalStatus":"Single","Over18":"Y","OverTime":"No"})
    path = tmp_path / "source.csv"
    pd.DataFrame([row]).to_csv(path,index=False)
    assert len(load_source(str(path))) == 1
    row["EmployeeNumber"] = 2
    row2 = {**row,"Age":17}
    pd.DataFrame([row,row2]).to_csv(path,index=False)
    with pytest.raises(ValueError): load_source(str(path))


def test_source_duplicate_identity_rejected(tmp_path):
    row={column:1 for column in EXPECTED_COLUMNS}
    row.update({"Age":30,"Attrition":"No","BusinessTravel":"Travel_Rarely","Department":"Sales","EducationField":"Other","Gender":"Female","JobRole":"Manager","MaritalStatus":"Single","Over18":"Y","OverTime":"No"})
    path=tmp_path/"source.csv"; pd.DataFrame([row,row]).to_csv(path,index=False)
    with pytest.raises(ValueError,match="unique"): load_source(str(path))
